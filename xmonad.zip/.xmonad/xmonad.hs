--
-- xmonad example config file.
--
-- A template showing all available configuration hooks,
-- and how to override the defaults in your own xmonad.hs conf file.
--
-- Normally, you'd only override those defaults you care about.
--

import XMonad
import Data.Monoid
import Data.Maybe (maybeToList)--fullscreen aux
import Control.Monad (when, join)--fullscreen aux
import System.Exit
import qualified XMonad.StackSet as W
import qualified Data.Map        as M

--Util
import XMonad.Util.Run(spawnPipe, hPutStrLn)
import XMonad.Util.SpawnOnce(spawnOnce)

--Hooks
import XMonad.Hooks.DynamicLog
import XMonad.Hooks.EwmhDesktops(ewmh, fullscreenEventHook) --fullscreen and compton
import XMonad.Hooks.ManageDocks
import XMonad.Hooks.ManageHelpers --doFullFloat
import XMonad.Hooks.UrgencyHook

--Keys
import Graphics.X11.ExtraTypes.XF86

--Layouts
import XMonad.Layout.Cross
import XMonad.Layout.NoBorders
import XMonad.Layout.MultiToggle
import XMonad.Layout.MultiToggle.Instances
import XMonad.Layout.Spacing
import XMonad.Layout.ThreeColumns
import XMonad.Layout.WindowNavigation

-- The preferred terminal program, which is used in a binding below and by
-- certain contrib modules.
--

myTerminal      = "urxvtc"
myBrowser       = "vivaldi-stable"
myGap           = 6
myFocusFollowsMouse = True
myClickJustFocuses = False
myBorderWidth   = 0
myModMask       = mod4Mask
myDzenIconDir   = "/home/robson/.xmonad/bitmaps/"

i    = "^i("++myDzenIconDir;
myWorkspaces = clickable $ ["1:"++ i ++ "coffee-cup.xbm)"
                           ,"2:"++ i ++ "fox.xbm)"
                           ,"3:"++ i ++ "cat_f.xbm)"
                           ,"4:"++ i ++ "muffin.xbm)"
                           ,"5:"++ i ++ "monster.xbm)"
                           ,"6:"++ i ++ "light.xbm)"
                           ,"7:"++ i ++ "ghost_P.xbm)"
                           ,"8:"++ i ++ "talk.xbm)"
                           ,"9:"++ i ++ "tv.xbm)"
                           ,"10:"++ i ++ "phones.xbm)"
                           ,"11:"++ i ++ "config.xbm)"
                           ]
       where clickable l = [ "^ca(1,xdotool key super+" 
                           ++ show (n) ++ ")" ++ ws ++ "^ca()" |
                           (i,ws) <- zip [1..] l,
                           let n = i ]


myWsBar         = "dzen2 -p -w 900 -ta l -e 'onstart=lower' -dock -fn Hermit" 
myInfoBar       = ("conky -c ~/.xmonad/status.conf | dzen2 -p -x 900 -w 1020 -ta r -e 'onstart=lower'  -dock -fn Hermit")

myWallpaperDir  = "~/Downloads/Images/FluidSnappyFox-size_restricted.gif"
--myWallpaperDir  = "~/Downloads/Images/].gif"
--myWallpaperDir  = "~/Downloads/Images/a.jpg"
--myWallpaperDir  = "~/Downloads/Images/a.gif"

-- Colors:
myBgColor  = "#1f201f"
myFgColor = "#959595"
--myThemeColor = "#8838FF"
myThemeColor = "#FF4262"
------------------------------------------------------------------------
-- Layouts:

-- You can specify and transform your layouts by modifying these values.
-- If you change layout bindings be sure to use 'mod-shift-space' after
-- restarting (with 'mod-q') to reset your layout state to the new
-- defaults, as xmonad preserves your old layout settings by default.
--
-- The available layouts.  Note that each layout is separated by |||,
-- which denotes layout choice.
--
myLayout = 
  mkToggle (single NBFULL) $
  avoidStruts $
  windowNavigation $
  smartBorders $
  normalLayout
  where
    
     -- default tiling algorithm partitions the screen into two panes
     tiled   = Tall 1 (3/100) (1/2)
     threeC  = ThreeColMid 1 (1/10) (1/2)
 
     --normalLayout = gaps [(U, gap),(D, gap),(L, gap), (R, gap)] ( spacing gap (
     normalLayout = spacingRaw False (Border myGap myGap myGap myGap) True (Border myGap myGap myGap myGap) True (
                threeC ||| Mirror threeC ||| simpleCross ||| tiled ||| Mirror tiled) ||| Full

-- Window rules:

-- Execute arbitrary actions and WindowSet manipulations when managing
-- a new window. You can use this to, for example, always float a
-- particular program, or have a client always appear on a particular
-- workspace.
--
-- To find the property name associated with a program, use
-- > xprop | grep WM_CLASS
-- and click on the client you're interested in.
--
-- To match on the WM_NAME, you can use 'title' in the same way that
-- 'className' and 'resource' are used below.
--
myManageHook = composeAll . concat $
    [ [ className =? c --> doFloat          | c <- floatingApp ]
    , [ className =? x --> doShift (w !! 1) | x <- my2Shifts ]
    , [ isFullscreen --> doFullFloat ]
    , [manageDocks]
    , [manageHook def]
    ]
    where
      w = myWorkspaces
      my2Shifts = ["Firefox"]
      floatingApp = [""]

------------------------------------------------------------------------
-- Event handling

-- * EwmhDesktops users should change this to ewmhDesktopsEventHook
--
-- Defines a custom handler function for X Events. The function should
-- return (All True) if the default handler is to be run afterwards. To
-- combine event hooks use mappend or mconcat from Data.Monoid.
--
myEventHook = handleEventHook def <+> fullscreenEventHook
--myEventHook = handleEventHook def <+> fullscreenEventHook <+> setTransparentHook

--Transparenty control when open window
--setTransparentHook :: Event -> X All
--setTransparentHook ConfigureRequestEvent{ ev_event_type = createNotify , ev_window = id} = do
--  setOpacity id opacity
--  return (All True)
--  where
--    opacityFloat = 0.8 
--    opacity = floor $ fromIntegral (maxBound :: Word32) * opacityFloat
--    setOpacity id op = spawn $ "xprop -id " ++ show id ++ " -f _NET_WM_WINDOW_OPACITY 32c -set _NET_WM_WINDOW_OPACITY " ++ show op
--setTransparentHook _ = return (All True)
------------------------------------------------------------------------
-- Key bindings. Add, modify or remove key bindings here.
--
myKeys conf@(XConfig {XMonad.modMask = modm}) = M.fromList $

    -- launch a terminal
    [ ((modm,               xK_Return), spawn $ XMonad.terminal conf)

    -- Restart xmonad
    , ((modm .|. shiftMask, xK_r     ), spawn "killall dzen2 conky & xmonad --restart")

    -- Quit xmonad
    , ((modm .|. shiftMask, xK_Escape), io (exitWith ExitSuccess))

    -- launch rofi 
    , ((modm,               xK_d     ), spawn ("rofi -show run -width 30 -lines 5 -font 'Hermit 13' "++
                                                  "-color-window '#1f201f, #1f201f, "++myThemeColor++"' "++
                                                  "-color-normal '#1f201f, #eeeeee, #1f201f, "++myThemeColor++", #1f201f'"))

    -- close focused window
    , ((modm .|. shiftMask, xK_q     ), kill)

    -- Stop Gif Wallpaper
    , ((modm              , xK_s     ), spawn ("killall xwinwrap | feh --bg-scale "++myWallpaperDir))

    --ScreenShot
    --, ((mod4Mask, xK_Print), spawn "scrot screen_%Y-%m-%d.png -d 1")
    --
    -- Volume Control
    , ((0,                  xF86XK_AudioMute),         spawn "amixer set Master toggle")
    , ((0,                  xF86XK_AudioRaiseVolume),  spawn "amixer set Master 1%+ unmute")
    , ((0,                  xF86XK_AudioLowerVolume),  spawn "amixer set Master 1%- unmute")
    
    -- Brightness Control
    , ((0,                  xF86XK_MonBrightnessUp),   spawn "light -A 5")
    , ((0,                  xF86XK_MonBrightnessDown), spawn "light -U 5")
 
    -- Opacity Control
    , ((modm .|. shiftMask,   xK_bracketleft     ), spawn "compton-trans -c 100")
    , ((modm .|. controlMask, xK_bracketleft     ), spawn "compton-trans -c --delete")
    , ((modm .|. shiftMask,   xK_bracketright    ), spawn "compton-trans -c 85")
    , ((modm,                 xK_bracketleft     ), spawn "compton-trans -c +5")
    , ((modm,                 xK_bracketright    ), spawn "compton-trans -c -5")

    -- Aplications
    , ((modm,                 xK_z     ), spawn (myTerminal ++ " -e ranger"))

    -- Browsers
    , ((modm,                 xK_f     ), spawn "firefox")
    , ((modm,                 xK_x     ), spawn myBrowser)

    , ((modm .|. controlMask, xK_m     ), spawn (myBrowser ++ " https://mail.google.com/mail/u/0/#inbox")) --Gmail
    , ((modm .|. controlMask, xK_d     ), spawn (myBrowser ++ " https://drive.google.com/drive/my-drive")) --Drive
    , ((modm .|. controlMask, xK_y     ), spawn (myBrowser ++ " https://www.youtube.com")) --Youtube

     -- Rotate through the available layout algorithms
    , ((modm,               xK_space ), sendMessage NextLayout)

    --  Reset the layouts on the current workspace to default
    , ((modm .|. shiftMask, xK_space ), setLayout $ XMonad.layoutHook conf)
    
    --  set current Layout in Full
    --, ((modm .|. shiftMask, xK_f ),     withFocused $ \f -> windows =<< appEndo `fmap` runQuery doFullFloat f)
    , ((modm .|. shiftMask, xK_f ),    sendMessage $ Toggle NBFULL)


    -- Move focus to the master window
    , ((modm,               xK_m     ), windows W.focusMaster  )

    -- Swap the focused window and the master window
    , ((modm .|. shiftMask, xK_m), windows W.swapMaster)


    -- Push window back into tiling
    , ((modm,               xK_t     ), withFocused $ windows . W.sink)

    -- Increment the number of windows in the master area
    , ((modm              , xK_comma ), sendMessage (IncMasterN 1))

    -- Deincrement the number of windows in the master area
    , ((modm              , xK_period), sendMessage (IncMasterN (-1)))

    -- Toggle the status bar gap
    -- Use this binding with avoidStruts from Hooks.ManageDocks.
    -- See also the statusBar function from Hooks.DynamicLog.
    --
    , ((modm              , xK_b     ), sendMessage ToggleStruts)

    -- Resize
    , ((modm,               xK_n    ), refresh)

    -- Resize viewed windows to the correct size
    , ((modm .|. controlMask,xK_Up       ), sendMessage Expand)
    , ((modm .|. controlMask,xK_Down     ), sendMessage Shrink)

    -- Navigation
    , ((modm,                xK_apostrophe   ), windows W.focusUp)
    , ((modm .|. shiftMask,  xK_apostrophe   ), windows W.swapUp)
    , ((modm,                xK_Tab          ), windows W.focusDown)
    , ((modm .|. shiftMask,  xK_Tab          ), windows W.swapDown)
   
    , ((modm,                 xK_Right), sendMessage $ Go R)
    , ((modm,                 xK_l),     sendMessage $ Go R)
    , ((modm,                 xK_Left ), sendMessage $ Go L)
    , ((modm,                 xK_h ),    sendMessage $ Go L)
    , ((modm,                 xK_Up   ), sendMessage $ Go U)
    , ((modm,                 xK_k   ),  sendMessage $ Go U)
    , ((modm,                 xK_Down ), sendMessage $ Go D)
    , ((modm,                 xK_j ),    sendMessage $ Go D)
    , ((modm .|. shiftMask,   xK_Right), sendMessage $ Swap R)
    , ((modm .|. shiftMask,   xK_l),     sendMessage $ Swap R)
    , ((modm .|. shiftMask,   xK_Left ), sendMessage $ Swap L)
    , ((modm .|. shiftMask,   xK_h ),    sendMessage $ Swap L)
    , ((modm .|. shiftMask,   xK_Up   ), sendMessage $ Swap U)
    , ((modm .|. shiftMask,   xK_k   ),  sendMessage $ Swap U)
    , ((modm .|. shiftMask,   xK_Down ), sendMessage $ Swap D)
    , ((modm .|. shiftMask,   xK_j ),    sendMessage $ Swap D)
   
    --, ((modm,   xK_y ),     opacityFloat = 1 )
    ]
    ++

    --
    -- mod-[1..9], Switch to workspace N
    -- mod-shift-[1..9], Move client to workspace N
    --
    [((m .|. modm, k), windows $ f i)
        | (i, k) <- zip (XMonad.workspaces conf) ([xK_1 .. xK_9]++[xK_0]++[xK_minus])
        , (f, m) <- [(W.greedyView, 0), (W.shift, shiftMask)]]

    --
    -- mod-{w,e,r}, Switch to physical/Xinerama screens 1, 2, or 3
    -- mod-shift-{w,e,r}, Move client to screen 1, 2, or 3
    --
    --[((m .|. modm, key), screenWorkspace sc >>= flip whenJust (windows . f))
    --    | (key, sc) <- zip [xK_w, xK_e, xK_r] [0..]
    --    , (f, m) <- [(W.view, 0), (W.shift, shiftMask)]]


------------------------------------------------------------------------
-- Mouse bindings: default actions bound to mouse events
--
myMouseBindings (XConfig {XMonad.modMask = modm}) = M.fromList $

    -- mod-button1, Set the window to floating mode and move by dragging
    [ ((modm, button1), (\w -> focus w >> mouseMoveWindow w
                                       >> windows W.shiftMaster))

    -- mod-button2, Raise the window to the top of the stack
    , ((modm, button2), (\w -> focus w >> windows W.shiftMaster))

    -- mod-button3, Set the window to floating mode and resize by dragging
    , ((modm, button3), (\w -> focus w >> mouseResizeWindow w
                                       >> windows W.shiftMaster))

    -- you may also bind events to the mouse scroll wheel (button4 and button5)
    ]

------------------------------------------------------------------------
-- Status bars and logging

-- Perform an arbitrary action on each internal state change or X event.
-- See the 'XMonad.Hooks.DynamicLog' extension for examples.
--
--myLogHook = return (
--myLogHook = dynamicLogWithPP $ sjanssenPP { ppOrder = reverse }
myLogHook h = dynamicLogWithPP $ def
    { 
      ppOutput  = hPutStrLn h
      , ppCurrent = dzenColor myThemeColor "" . pad
      , ppVisible = pad
      , ppHidden  = pad
      , ppUrgent  = dzenColor myBgColor myThemeColor . pad
      , ppSep     = ""
      , ppOrder   = \(ws:l:t:_) -> [ws,l]
      , ppLayout  = dzenColor myThemeColor "" . pad .
        (\ x -> case x of
            "Spacing ThreeCol"         -> icon "layout_three_columns.xbm"
            "Spacing Mirror ThreeCol"  -> icon "layout_mirror_three_columns.xbm"
            "Spacing Cross"            -> icon "layout_cross.xbm"
            "Spacing Tall"             -> icon "layout_tall.xbm"
            "Spacing Mirror Tall"      -> icon "layout_mirror_tall.xbm"
            "Full"                     -> icon "layout_full.xbm"
            _                          -> pad x
         )
    }
    where
      icon h = "^i("++myDzenIconDir++ h ++ ")"

------------------------------------------------------------------------
-- Startup hook

-- Perform an arbitrary action each time xmonad starts or is restarted
-- with mod-q.  Used by, e.g., XMonad.Layout.PerWorkspace to initialize
-- per-workspace layout choices.
--
-- By default, do nothing.
myStartupHook = do 
  docksStartupHook 
  addEWMHFullscreen
  spawnOnce "compton -config ~/.config/compton/compton.conf"
  spawn ("wallpaper " ++ myWallpaperDir)

--Fullscreen Complement
addNETSupported :: Atom -> X ()
addNETSupported x   = withDisplay $ \dpy -> do
    r               <- asks theRoot
    a_NET_SUPPORTED <- getAtom "_NET_SUPPORTED"
    a               <- getAtom "ATOM"
    liftIO $ do
       sup <- (join . maybeToList) <$> getWindowProperty32 dpy a_NET_SUPPORTED r
       when (fromIntegral x `notElem` sup) $
         changeProperty32 dpy r a_NET_SUPPORTED a propModeAppend [fromIntegral x]

addEWMHFullscreen :: X ()
addEWMHFullscreen   = do
    wms <- getAtom "_NET_WM_STATE"
    wfs <- getAtom "_NET_WM_STATE_FULLSCREEN"
    mapM_ addNETSupported [wms, wfs]
   --
------------------------------------------------------------------------
-- Now run xmonad with all the defaults we set up.

-- Run xmonad with the settings you specify. No need to modify this.
--
main = do
  d <- spawnPipe myWsBar
  spawnPipe $ myInfoBar
  xmonad
    $ docks
    $ ewmh --compton
    -- $ withUrgencyHook NoUrgencyHook
    def {
      -- simple stuff
        terminal           = myTerminal,
        focusFollowsMouse  = myFocusFollowsMouse,
        clickJustFocuses   = myClickJustFocuses,
        borderWidth        = myBorderWidth,
        modMask            = myModMask,
        workspaces         = myWorkspaces,
        normalBorderColor  = myFgColor,
        focusedBorderColor = myThemeColor,

      -- key bindings
        keys               = myKeys,
        mouseBindings      = myMouseBindings,

      -- hooks, layouts
        layoutHook         = myLayout,
        manageHook         = myManageHook,
        handleEventHook    = myEventHook,
        logHook            = myLogHook d,
        startupHook        = myStartupHook
    }

 
